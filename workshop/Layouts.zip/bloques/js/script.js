function changeStyle(opt){
	document.getElementById("idStyle").setAttribute("href", "css/"+opt+".css");
}